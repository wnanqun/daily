from spsspro.algorithm import descriptive_analysis
import pandas as pd
filename="相关性分析.xlsx"
df1=pd.read_excel(filename)

wensh=df1.iloc[:,[2]]
type=df1.iloc[:,[3]]
color=df1.iloc[:,[4]]
fenhua=df1.iloc[:,[5]]

#数据
data = pd.DataFrame({
    "A": wensh,
    "B":type,
    "C":color,
    "D":fenhua
})
#相关性分析
result = descriptive_analysis.correlation_analysis(data)
print(result)



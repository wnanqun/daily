filename="全是铅钡.xlsx"
import numpy
import pandas
from spsspro.algorithm import statistical_model_analysis
#生成数据
df1=pd.read_excel(filename)
dad=[]
for i in range(6,20):
    dad[i]=df1.iloc[:,[i-1]]
data=pandas.DataFrame({dad})

#聚类分析
result = statistical_model_analysis.cluster_analysis(data, cluster_num=3)
print(result)


filename="随机森林分析.xlsx"
import numpy  as np
import pandas as pd
from spsspro.algorithm import supervised_learning

#生成数据
df1=pd.read_excel(filename)
dad=[]
for i in range(7,20):
    dad[i]=df1.iloc[:,[i-1]]
data=pd.DataFrame({dad})
data=np.array(data)

data_x = pd.DataFrame({
    data
})


data_y=df1.iloc[:,[3]]
data_y = pd.Series(np.array(data_y), name="C")
#随机森林分类
result = supervised_learning.random_forest_classifier(data_x=data_x, data_y=data_y)
print(result)
